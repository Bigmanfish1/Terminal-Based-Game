#include "Floor.h"

using namespace std;

Floor::Floor(int x, int y): Object(x, y){
    icon = '.';
}