#include "Wall.h"

using namespace std;

Wall::Wall(int x, int y): Object(x, y){
    icon = '#';
}
