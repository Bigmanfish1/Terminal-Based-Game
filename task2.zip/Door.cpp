#include "Door.h"

using namespace std;

Door::Door(int x, int y, bool open): Object(x, y){
    this->open = open;
    if(open == true){
        icon = '=';
        solid = false;
    }else if(open == false){
        icon = '+';
        solid = true;
    }
}

void Door::interact(){
    if(open == true){
        open = false;
        icon = '+';
        solid = true;
        throw string("You closed a door");
    }else if(open == false){
        open = true;
        icon = '=';
        solid = false;
        throw string("You opened a door");
    }
    
}

void Door::updateLight(char direction, int intensity){
    if(open == true){
        Object::updateLight(direction, intensity);
    }else if(open == false){
        Object::updateLight(direction, 1);
    }
}
