#ifndef EXIT_H
#define EXIT_H

#include "Object.h"

class Exit: public Object{
    public:
        Exit(int x, int y);
};
#endif
