#include "Game.h"

using namespace std;

Game::Game(int w, int h, string chars)
{
    map = new Map(w, h);
    int index = 0;
    player = NULL; 
    for (int i = 0; i < h; i++)
    {
        for (int j = 0; j < w; j++)
        {
            if (chars[index] == '&')
            {
                Floor *floor = new Floor(j, i);
                player = new Player(j, i);
                floor->above = player;
                player->below = floor;
                map->add(floor);
            }
            else if (chars[index] == '#')
            {
                Wall *wall = new Wall(j, i);
                map->add(wall);
            }
            else if (chars[index] == '.')
            {
                Floor *floor = new Floor(j, i);
                map->add(floor);
            }
            else if (chars[index] == '?')
            {
                Object *ob = new Object(j, i);
                map->add(ob);
            }
            else if (chars[index] == '=')
            {
                Door *door = new Door(j, i, true);
                map->add(door);
            }
            else if (chars[index] == '+')
            {
                Door *door = new Door(j, i, false);
                map->add(door);
            }
            else if (chars[index] == '@')
            {
                exit = new Exit(j, i);
                map->add(exit);
            }
            else if (chars[index] == '^')
            {
                Lamp *lamp = new Lamp(j, i);
                Floor *floor = new Floor(j, i);
                lamp->below = floor;
                floor->above = lamp;
                map->add(floor);
                map->addLight(lamp);
            }

            index++;
        }
    }

    messages = new MessageQueue(4);
    map->resetEnvironment();
    map->updateEnvironment();
}

Game::~Game()
{
    if (map != NULL)
    {
        delete map;
        map = NULL;
    }

    if (player != NULL)
    {
        delete player;
        player = NULL;
    }

    if (messages != NULL)
    {
        delete messages;
        messages = NULL;
    }
}

string Game::display()
{
    string res = "";
    res += messages->print();
    res += map->print();
    return res;
}

void Game::update(char input)
{
    if (player == NULL)
    {
        string val = "Missing player";
        Message *mes = new Message(val);
        messages->addMessage(mes);
    }
    else
    {

        if (input == '1')
        {
            if (player != NULL)
            {
                if (map->getAt(player->getCoord(false) - 1, player->getCoord(true) + 1) == NULL)
                {
                    string val = "Out of bounds";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else if (map->getAt(player->getCoord(false) - 1, player->getCoord(true) + 1)->isSolid() == true)
                {
                    string val = "Walked into something";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else
                {
                    player->move(-1, 1);
                    if (map->getAt(player->getCoord(false), player->getCoord(true)) == exit)
                    {
                        throw string("You reached the exit!");
                    }
                    map->resetEnvironment();
                    map->updateEnvironment();
                }
            }
        }
        else if (input == '2')
        {
            if (player != NULL)
            {
                if (map->getAt(player->getCoord(false), player->getCoord(true) + 1) == NULL)
                {
                    string val = "Out of bounds";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else if (map->getAt(player->getCoord(false), player->getCoord(true) + 1)->isSolid() == true)
                {
                    string val = "Walked into something";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else
                {
                    player->move(0, 1);
                    if (map->getAt(player->getCoord(false), player->getCoord(true)) == exit)
                    {
                        throw string("You reached the exit!");
                    }
                    map->resetEnvironment();
                    map->updateEnvironment();
                }
            }
        }
        else if (input == '3')
        {
            if (player != NULL)
            {
                if (map->getAt(player->getCoord(false) + 1, player->getCoord(true) + 1) == NULL)
                {
                    string val = "Out of bounds";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else if (map->getAt(player->getCoord(false) + 1, player->getCoord(true) + 1)->isSolid() == true)
                {
                    string val = "Walked into something";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else
                {
                    player->move(1, 1);
                    if (map->getAt(player->getCoord(false), player->getCoord(true)) == exit)
                    {
                        throw string("You reached the exit!");
                    }
                    map->resetEnvironment();
                    map->updateEnvironment();
                }
            }
        }
        else if (input == '4')
        {
            if (player != NULL)
            {
                if (map->getAt(player->getCoord(false) - 1, player->getCoord(true)) == NULL)
                {
                    string val = "Out of bounds";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else if (map->getAt(player->getCoord(false) - 1, player->getCoord(true))->isSolid() == true)
                {
                    string val = "Walked into something";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else
                {
                    player->move(-1, 0);
                    if (map->getAt(player->getCoord(false), player->getCoord(true)) == exit)
                    {
                        throw string("You reached the exit!");
                    }
                    map->resetEnvironment();
                    map->updateEnvironment();
                }
            }
        }
        else if (input == '6')
        {
            if (player != NULL)
            {
                if (map->getAt(player->getCoord(false) + 1, player->getCoord(true)) == NULL)
                {
                    string val = "Out of bounds";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else if (map->getAt(player->getCoord(false) + 1, player->getCoord(true))->isSolid() == true)
                {
                    string val = "Walked into something";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else
                {
                    player->move(1, 0);
                    if (map->getAt(player->getCoord(false), player->getCoord(true)) == exit)
                    {
                        throw string("You reached the exit!");
                    }
                    map->resetEnvironment();
                    map->updateEnvironment();
                }
            }
        }
        else if (input == '7')
        {
            if (player != NULL)
            {
                if (map->getAt(player->getCoord(false) - 1, player->getCoord(true) - 1) == NULL)
                {
                    string val = "Out of bounds";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else if (map->getAt(player->getCoord(false) - 1, player->getCoord(true) - 1)->isSolid() == true)
                {
                    string val = "Walked into something";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else
                {
                    player->move(-1, -1);
                    if (map->getAt(player->getCoord(false), player->getCoord(true)) == exit)
                    {
                        throw string("You reached the exit!");
                    }
                    map->resetEnvironment();
                    map->updateEnvironment();
                }
            }
        }
        else if (input == '8')
        {
            if (player != NULL)
            {
                if (map->getAt(player->getCoord(false), player->getCoord(true) - 1) == NULL)
                {
                    string val = "Out of bounds";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else if (map->getAt(player->getCoord(false), player->getCoord(true) - 1)->isSolid() == true)
                {
                    string val = "Walked into something";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else
                {
                    player->move(0, -1);
                    if (map->getAt(player->getCoord(false), player->getCoord(true)) == exit)
                    {
                        throw string("You reached the exit!");
                    }
                    map->resetEnvironment();
                    map->updateEnvironment();
                }
            }
        }
        else if (input == '9')
        {
            if (player != NULL)
            {
                if (map->getAt(player->getCoord(false) + 1, player->getCoord(true) - 1) == NULL)
                {
                    string val = "Out of bounds";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else if (map->getAt(player->getCoord(false) + 1, player->getCoord(true) - 1)->isSolid() == true)
                {
                    string val = "Walked into something";
                    Message *mes = new Message(val);
                    messages->addMessage(mes);
                }
                else
                {
                    player->move(1, -1);
                    if (map->getAt(player->getCoord(false), player->getCoord(true)) == exit)
                    {
                        throw string("You reached the exit!");
                    }
                    map->resetEnvironment();
                    map->updateEnvironment();
                }
            }
        }
        else if (input == 'e')
        {
            if(player != NULL){
                Object* tempU = map->getAt(player->getCoord(false), player->getCoord(true) - 1);
                if(tempU != NULL){
                    playerInteract(tempU);
                }

                Object* tempD = map->getAt(player->getCoord(false), player->getCoord(true) + 1);
                if(tempD != NULL){
                    playerInteract(tempD);
                }

                Object* tempL = map->getAt(player->getCoord(false) - 1, player->getCoord(true));
                if(tempL != NULL){
                    playerInteract(tempL);
                }

                Object* tempR = map->getAt(player->getCoord(false) + 1, player->getCoord(true));
                if(tempR != NULL){
                    playerInteract(tempR);
                }
                 
                map->resetEnvironment();
                map->updateEnvironment();
            }
            
        }
    }
}

void Game::playerInteract(Object *obj)
{
    Object *topO = obj;
    if (topO != NULL)
    {
        while (topO->above != NULL)
        {
            topO = topO->above;
        }

        try
        {
            topO->interact();
        }
        catch (string y)
        {
            Message *newM = new Message(y);
            messages->addMessage(newM);
        }
    }
}