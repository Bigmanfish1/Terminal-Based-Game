#include "Lamp.h"

using namespace std;

Lamp::Lamp(int x, int y): Object(x,y){
    icon = '^';
    solid = true;
}

void Lamp::update(){
    Object* node = this;
    while(node->below != NULL){
        node = node->below;
    }

    node->updateLight('u',1);
    if(node->prevHoriz != NULL){
        node->prevHoriz->updateLight('l', 20);
    }
    if(node->nextHoriz != NULL){
        node->nextHoriz->updateLight('r', 20);
    }
    if(node->nextVert != NULL){
        node->nextVert->updateLight('d', 20);
    }
    if(node->prevVert != NULL){
        node->prevVert->updateLight('u', 20);
    }
    
}