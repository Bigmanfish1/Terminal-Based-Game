#include "Map.h"

using namespace std;

Map::Map(int w, int h)
{
    width = w;
    height = h;
    rows = new ObjectList *[height];
    for (int i = 0; i < height; i++)
    {
        rows[i] = new ObjectList(false);
    }

    columns = new ObjectList *[width];
    for (int i = 0; i < width; i++)
    {
        columns[i] = new ObjectList(true);
    }

    lights = new ObjectList(false);
}

Map::~Map()
{
    if (rows != NULL)
    {
        for (int i = 0; i < height; i++)
        {
            if (rows[i] != NULL)
            {
                Object *temp = rows[i]->getHead();
                while (temp != NULL)
                {
                    Object *tempH = temp->getNext(false);
                    delete temp;
                    temp = tempH;
                }
                delete rows[i];
            }
        }
        delete[] rows;
        rows = NULL;
    }

    if (columns != NULL)
    {
        for (int i = 0; i < width; i++)
        {
            if (columns[i] != NULL)
            {
                delete columns[i];
            }
        }
        delete[] columns;
        columns = NULL;
    }

    Object *t = lights->getHead();
    if (t != NULL)
    {
        while (t != NULL)
        {
            Object *temp = t->getNext(false);
            delete t;
            t = temp;
        }
    }

    delete lights;
    lights = NULL;
}

void Map::add(Object *obj)
{
    int y = obj->getCoord(true);
    int x = obj->getCoord(false);

    rows[y]->add(obj);
    columns[x]->add(obj);
}

string Map::print()
{
    string res = "";
    for (int i = 0; i < height; i++)
    {
        res += rows[i]->print() + "\n";
    }

    return res;
}

Object *Map::getAt(int x, int y)
{
    Object *node = NULL;
    if ((x > -1 && x < width) && (y > -1 && y < height))
    {
        rows[y]->reset();
        while (Object *p = rows[y]->iterate())
        {
            if (p->getCoord(false) == x && p->getCoord(true) == y)
            {
                node = p;
                break;
            }
        }
    }

    return node;
}

void Map::addLight(Object *light)
{
    lights->add(light);
    // Object* temp = getAt(light->getCoord(false), light->getCoord(true));
}

void Map::resetEnvironment()
{
    for (int i = 0; i < height; i++)
    {
        Object *node = rows[i]->getHead();
        while (node != NULL)
        {
            node->update();
            node = node->nextHoriz;
        }
    }
}

void Map::updateEnvironment()
{
    // Object *temp = lights->getHead();
    lights->reset();
    while (Object *p = lights->iterate())
        p->update();
}