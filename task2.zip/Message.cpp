#include "Message.h"

using namespace std;

Message::Message(string t){
    text = t;
    next = NULL;
}

string Message::getText(){
    return text;
}
