#include "MessageQueue.h"

using namespace std;

MessageQueue::MessageQueue(int timeout)
{
    MessageQueue::timeout = timeout;
    head = NULL;
    tail = NULL;
    current = timeout;
}

MessageQueue::~MessageQueue()
{
    Message *node = head;
    while (node != NULL)
    {
        head = head->next;
        delete node;
        node = head;
    }
    tail = NULL;
}

void MessageQueue::addMessage(Message *m)
{
    if (head == NULL)
    {
        head = m;
        tail = m;
    }
    else
    {
        tail->next = m;
        tail = m;
    }
}

string MessageQueue::print()
{
    string res = "";
    if (head != NULL)
    {
        Message *messagePtr = head;
        while (messagePtr != NULL)
        {
            res += messagePtr->getText() + "\n";
            messagePtr = messagePtr->next;
        }

        current -= 1;

        if (current == 0)
        {
            if (head != NULL)
            {
                /*
                if(head == tail){
                    messagePtr = head;
                    delete messagePtr;
                    head = NULL;
                    tail = NULL;
                }
                */
                messagePtr = head;
                head = head->next;
                delete messagePtr;
                
            }
            current = timeout;
        }
    }

    return res;
}