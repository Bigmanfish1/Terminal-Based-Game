#include "Object.h"

using namespace std;

Object::Object(int x, int y)
{
    xPos = x;
    yPos = y;
    icon = '?';
    nextHoriz = NULL;
    prevHoriz = NULL;
    nextVert = NULL;
    prevVert = NULL;
    above = NULL;
    below = NULL;
    lit = true;
    solid = true;
}

char Object::getIcon()
{
    Object *temp = this;
    char val;

    while (temp->below != NULL)
    {
        temp = temp->below;
    }

    if (temp->lit == true)
    {
        while (temp->above != NULL)
        {
            temp = temp->above;
        }
        val = temp->icon;
    }
    else
    {
        val = ' ';
    }

    return val;
}

int Object::getCoord(bool dimension)
{
    int pos;
    if (dimension == false)
    {
        pos = xPos;
    }
    else if (dimension == true)
    {
        pos = yPos;
    }

    return pos;
}

Object *Object::getNext(bool dimension)
{
    Object *temp;
    if (dimension == false)
    {
        temp = this->nextHoriz;
    }
    else if (dimension == true)
    {
        temp = this->nextVert;
    }

    return temp;
}

Object *Object::getPrev(bool dimension)
{
    Object *temp;
    if (dimension == false)
    {
        temp = this->prevHoriz;
    }
    else if (dimension == true)
    {
        temp = this->prevVert;
    }

    return temp;
}

void Object::setNext(Object *ob, bool dim)
{
    if (dim == false)
    {
        this->nextHoriz = ob->nextHoriz;
    }
    else if (dim == true)
    {
        this->nextVert = ob->nextVert;
    }
}

void Object::setPrev(Object *ob, bool dim)
{
    if (dim == false)
    {
        this->prevHoriz = ob->prevHoriz;
    }
    else if (dim == true)
    {
        this->prevVert = ob->prevVert;
    }
}

bool Object::isSolid()
{
    bool val;
    if (this->solid == false)
    {
        if(this->above != NULL){
            if(this->above->solid == true){
                val = true;
            }
        }else{
            val = false;
        }
        
    }
    else
    {
        val = solid;
    }
    return val;
}

void Object::interact()
{
}

void Object::update()
{
    lit = false;
}

void Object::updateLight(char direction, int intensity)
{
    if (intensity == 1)
    {
        lit = true;
    }
    else
    {
        lit = true;
        if (direction == 'u')
        {
            if (this->prevVert != NULL)
            {
                this->prevVert->updateLight(direction, intensity - 1);
            }

            if (this->prevHoriz != NULL)
            {
                this->prevHoriz->updateLight(direction, 1);
            }

            if (this->nextHoriz != NULL)
            {
                this->nextHoriz->updateLight(direction, 1);
            }
        }
        else if (direction == 'd')
        {
            if (this->nextVert != NULL)
            {
                this->nextVert->updateLight(direction, intensity - 1);
            }

            if (this->prevHoriz != NULL)
            {
                this->prevHoriz->updateLight(direction, 1);
            }

            if (this->nextHoriz != NULL)
            {
                this->nextHoriz->updateLight(direction, 1);
            }
        }
        else if (direction == 'l')
        {
            if (this->prevHoriz != NULL)
            {
                this->prevHoriz->updateLight(direction, intensity - 1);
            }

            if (this->prevVert != NULL)
            {
                this->prevVert->updateLight(direction, 1);
            }

            if (this->nextVert != NULL)
            {
                this->nextVert->updateLight(direction, 1);
            }
        }
        else if (direction == 'r')
        {
            if (this->nextHoriz != NULL)
            {
                this->nextHoriz->updateLight(direction, intensity - 1);
            }

            if (this->prevVert != NULL)
            {
                this->prevVert->updateLight(direction, 1);
            }

            if (this->nextVert != NULL)
            {
                this->nextVert->updateLight(direction, 1);
            }
        }
    }
}